<?php include("includes/header.php"); ?>
<?php include("admin/includes/functions.php"); ?>

<?php

if (isset($_POST['subscribe'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $job_field = $_POST['job_field'];
    $package = $_POST['package'];
    $details = $_POST['details'];
    $skill = $_POST['skill'];
}else{
    redirect("reg.php");
}
?>


<div class="row">
    <div class="col-md-12">
        <div class="container-fluid">
            <div style="margin-top: 40px;">
                <h1 style="text-align: center; color: #6A33D3; margin: 0; padding: 0;">Payment Detailts</h1>
                <div style="background: #fff; padding: 30px; border-radius: 10px; max-width: 500px ; margin: auto;">
                    <form action="includes/plan.php" method="post" enctype="multipart/form-data">
                        <ul class="list-group">
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Package
                                <span class="badge badge-primary badge-pill"><?php echo $package; ?></span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Price
                                <span class="badge badge-primary badge-pill">
                                    <?php

                                    $basic = "Basic";
                                    $pro = "Pro";
                                    $premium = "Premium";
                                    if ($package == $basic) {
                                        echo "$ 9.99";
                                    } elseif ($package == $pro) {
                                        echo "$ 19.99";
                                    } elseif ($package == $premium) {
                                        echo "$ 29.99";
                                    } else {
                                        echo "Unknown";
                                    }


                                    ?>
                                </span>
                            </li>
                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                Payment By
                                <span class="badge badge-primary badge-pill">Unknown</span>
                            </li>
                        </ul>

                        <input type="hidden" name="fname" value="<?php echo $fname; ?>">
                        <input type="hidden" name="lname" value="<?php echo $lname; ?>">
                        <input type="hidden" name="username" value="<?php echo $username; ?>">
                        <input type="hidden" name="email" value="<?php echo $email; ?>">
                        <input type="hidden" name="pwd" value="<?php echo $pwd; ?>">
                        <input type="hidden" name="job_field" value="<?php echo $job_field; ?>">
                        <input type="hidden" name="package" value="<?php echo $package; ?>">
                        <input type="hidden" name="details" value="<?php echo $details; ?>">
                        <input type="hidden" name="skill" value="<?php echo $skill; ?>">
                        <div class="form-group">
                            <label for="">Photo</label>
                            <input type="file" name="photo">
                        </div>
                        <div class="form-group">
                            <label for="">CV</label>
                            <input type="file" name="cv">
                            <small>Note: Only PDF accepted</small>
                        </div>

                        <div class="form-group">
                            <button name="confirm" type="submit" class="btn btn-block">Confirm</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include("includes/footer.php"); ?>