 <!-- Side Widget Well -->
 <div class="well" style="margin-top:80px;">
     <h4>Side Widget Well</h4>
     <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Inventore, perspiciatis adipisci accusamus laudantium odit aliquam repellat tempore quos aspernatur vero.</p>
 </div>
 <!-- Blog Categories Well -->
 <div class="well">
     <div class="row">
         <div class="col-lg-12">
             <div class="container-fluid">
                 <div class=style="background: #fff; padding: 30px; border-radius: 10px;max-width: 500px ; margin: auto;">
                     
                     <?php 
                     
                     if(isset($_SESSION['username'])):
                        echo "Hello, ". $_SESSION['username'];
                        echo " <a class='btn btn-danger' href='admin/logout.php'> Logout</a>";
                     else:
                     ?>
                      
                     <form action="includes/login.php" method="POST">
                         <div class="form-group">
                             <input class="form-control" type="email" placeholder="E-mail" name="email">
                         </div>
                         <div class="form-group">
                             <input class="form-control" type="password" placeholder="Password" name="pwd">
                         </div>
                         <div class="form-group">
                             <button style="width:49%;" class="btn btn-success" type="submit" name="login">Login</button>
                             <a href="forgot.php" style="width:48%;" class="btn btn-danger">Forgot Password</a>
                             <a href="reg.php" class="btn btn-primary btn-block">Registration</a>
                         </div>
                     </form>
                     <?php endif; ?>
                     
                 </div>
             </div>
         </div>
         <!-- /.col-lg-6 -->
     </div>
     <!-- /.row -->
 </div>