<?php include("../admin/includes/functions.php"); ?>
<?php 

if(isset($_POST['login'])){
    login_user($_POST['email'],$_POST['pwd']);
}




?>