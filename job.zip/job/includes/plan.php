<?php include("../admin/includes/functions.php"); ?>
<?php 
if (isset($_POST['confirm'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    $job_field = $_POST['job_field'];
    $package = $_POST['package'];
    $details = $_POST['details'];
    $skill = $_POST['skill'];
    $photo = $_FILES['photo'];
    $cv = $_FILES['cv'];

    reg_user($fname, $lname, $username, $email, $pwd, $job_field,$package,$details,$skill,$photo,$cv);
}






?>