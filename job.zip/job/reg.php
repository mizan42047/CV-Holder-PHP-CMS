<?php include("includes/header.php"); ?>
<?php include("admin/includes/functions.php"); ?>

<div class="row">
    <!-- Blog Entries Column -->
    <div class="col-md-12">
        <div class="container-fluid">
            <div style="margin-top: 40px;">
                <h1 style="text-align: center; color: #6A33D3; margin: 0; padding: 0;">Subscription Form</h1>
                <div style="background: #fff; padding: 30px; border-radius: 10px; max-width: 500px ; margin: auto;">
                <?php 
                
                if(isset($_SESSION['ucreate_error'])){
                    if(!empty($_SESSION['ucreate_error'])){
                        $message = $_SESSION['ucreate_error'];
                        echo '<div class="alert alert-danger">'.$message.'</div>';
                        unset($_SESSION['ucreate_error']);
                    }
                }
                
                ?>
                    <form action="payment.php" method="POST" enctype="multipart/form-data">
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="First Name" name="fname">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="Last Name" name="lname">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="text" placeholder="Username" name="username">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="email" placeholder="E-mail" name="email">
                        </div>
                        <div class="form-group">
                            <input class="form-control" type="password" placeholder="Password" name="pwd">
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="job_field" id="">
                                <option value="Others">SELECT A Job Field</option>
                                <?php
                                $query = find_job_field();
                                while ($result = mysqli_fetch_array($query)) {
                                    echo "<option value='" . $result['job_name'] . "'>" . $result['job_name'] . "</option>";
                                }
                                ?>

                            </select>
                        </div>
                        <div class="form-group">
                            <select class="form-control" name="package">
                                <option value="Basic">Select A Package</option>
                                <option value="Basic">Basic</option>
                                <option value="Pro">Pro</option>
                                <option value="Premium">Premium</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <textarea name="details" class="form-control" id="details" cols="30" rows="10">Write Your Details</textarea>
                        </div>
                        <div class="form-group">
                            <textarea name="skill" class="form-control" id="skill" cols="30" rows="10">Write Your Job Skill</textarea>
                        </div>
                        <div class="form-group">
                            <button class="btn btn-success btn-block" type="submit" name="subscribe">Subscribe</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>

    <?php include("includes/footer.php"); ?>

    <script>
        var alert = document.querySelector(".alert");
        setInterval(function(){
            alert.style.display = "none";
        },2000);

        ClassicEditor
        .create( document.querySelector( '#details' ) )
        .catch( error => {
            console.error( error );
        } );
        ClassicEditor
        .create( document.querySelector( '#skill' ) )
        .catch( error => {
            console.error( error );
        } );
    </script>