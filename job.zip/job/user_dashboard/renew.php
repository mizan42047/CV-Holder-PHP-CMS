<?php include("../admin/includes/functions.php"); ?>
<?php include("includes/header.php"); ?>
<?php

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if (is_user_logged_in($username) == false) {
        redirect("../index.php");
    } elseif (user_type($role) == false) {
        redirect("../index.php");
    }
} else {
    redirect("../index.php");
}
?>

<div class="row">
    <!-- Blog Entries Column -->
    <div class="col-md-4">
        <h3 class="text-center">Basic</h3>
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Package
                <span class="badge badge-primary badge-pill">Basic</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Price
                <span class="badge badge-primary badge-pill">$ 9.99</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Support
                <span class="badge badge-primary badge-pill">1 Month</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <form action="includes/renew_pack.php" method="POST">
                    <button type="submit" onClick="javascript: return confirm('Are you Sure want to Renew?');" class="btn btn-primary btn-block" name="basic">Renew</button>
                </form>
            </li>
        </ul>
    </div>
    <div class="col-md-4">
    <h3 class="text-center">Pro</h3>
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Package
                <span class="badge badge-primary badge-pill">Pro</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Price
                <span class="badge badge-primary badge-pill">$ 19.99</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Support
                <span class="badge badge-primary badge-pill">6 Month</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <form action="includes/renew_pack.php" method="POST">
                    <button type="submit" onClick="javascript: return confirm('Are you Sure want to Renew?');" class="btn btn-success btn-block" name="pro">Renew</button>
                </form>
            </li>
        </ul>
    </div>
    <div class="col-md-4">
    <h3 class="text-center">Premium</h3>
        <ul class="list-group">
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Package
                <span class="badge badge-primary badge-pill">Premium</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Price
                <span class="badge badge-primary badge-pill">$ 29.99</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                Support
                <span class="badge badge-primary badge-pill">1 Year</span>
            </li>
            <li class="list-group-item d-flex justify-content-between align-items-center">
                <form action="includes/renew_pack.php" method="POST">
                    <button type="submit" onClick="javascript: return confirm('Are you Sure want to Renew?');" class="btn btn-danger btn-block" name="premium">Renew</button>
                </form>
            </li>
        </ul>
    </div>
    <!-- Blog Sidebar Widgets Column -->

    <?php include("includes/footer.php"); ?>