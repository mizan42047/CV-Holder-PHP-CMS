<?php include("../admin/includes/functions.php"); ?>
<?php include("includes/header.php"); ?>
<?php 

if(isset($_SESSION['username']) && isset($_SESSION['role'])){
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if(is_user_logged_in($username) == false){
        redirect("../index.php");
    }elseif(user_type($role) == false){
        redirect("../index.php");
    }
}else{
    redirect("../index.php");
}

$data = find_by_username($_SESSION['username']);
$photo = $data['photo'];
$fanme = $data['first_name'];
$lanme = $data['last_name'];
$details = $data['datails'];
$skill = $data['skill'];
$email = $data['email'];
$package = $data['package'];
$job_field = $data['job_field'];
$username = $data['username'];
$status = $data['status'];
$cv_file = $data['cv_file'];
$cv_count = $data['cv_sent_count'];
$remaining_day = $data['remaining_day'];

$date = time();
$expire_date  = time()+$remaining_day;



if($date >= $expire_date){
    $sql = "UPDATE subscriber SET status = 'Expired', cv_sent_count = 0 WHERE username = '$username'";
    $query = query($sql);
    confirm($query);
    notify_reg("date expired",$username);
}else{
    $sql = "UPDATE subscriber SET status = 'Running' WHERE username = '$username'";
    $query = query($sql);
}
?>

<div class="row">
    <!-- Blog Entries Column -->
    <div class="col-md-8">
        <div class="container-fluid">
            <div style="background: #fff; padding: 30px; border-radius: 10px; max-width: 500px ; margin: auto;">
                <form action="includes/update_sub.php" method="POST" enctype="multipart/form-data">
                    <div style="width: 100%;text-align: center;">
                        <?php if (empty($photo)) : ?>
                            <img style="width:100px;height:100px;border-radius:50%;margin-bottom:15px;" src="../admin/images/pngtree-user-vector-avatar-png-image_1541962.jpg" alt="">
                        <?php else : ?>
                            <img style="width:100px;height:100px;border-radius:50%;margin-bottom:15px;" src="../admin/images/<?php echo $photo; ?>" alt="">
                        <?php endif; ?>
                    </div>
                    <div class="form-group">
                        <label for="">Change Photo</label>
                        <input type="file" name="photo">
                    </div>
                    <div class="form-group">
                        <label for="">Change CV</label>
                        <input type="file" name="user_cv">
                    </div>
                    <div class="form-group">
                        <input class="form-control" type="text" placeholder="First Name" name="fname" value="<?php echo $fanme; ?>">
                    </div>
                    <div class="form-group">
                        <input value="<?php echo $lanme; ?>" class="form-control" type="text" placeholder="Last Name" name="lname">
                    </div>
                    <div class="form-group">
                        <textarea name="details" class="form-control" id="details" cols="30" rows="10"><?php echo $details; ?></textarea>
                    </div>
                    <div class="form-group">
                        <textarea name="skill" class="form-control" id="skill" cols="30" rows="10"><?php echo $skill; ?></textarea>
                    </div>
            </div>
        </div>
    </div>
    <!-- Blog Sidebar Widgets Column -->
    <div class="col-md-4">
        <?php include("includes/sidebar.php"); ?>
    </div>
    </form>
    <!-- /.row -->

    <?php include("includes/footer.php"); ?>

    <script>
        var alert = document.querySelector(".alert");
        setInterval(function() {
            alert.style.display = "none";
        }, 2000);
        ClassicEditor
            .create(document.querySelector('#details'))
            .catch(error => {
                console.error(error);
            });
        ClassicEditor
            .create(document.querySelector('#skill'))
            .catch(error => {
                console.error(error);
            });
    </script>