<?php include("../admin/includes/functions.php"); ?>
<?php include("includes/header.php"); ?>
<?php

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if (is_user_logged_in($username) == false) {
        redirect("../index.php");
    } elseif (user_type($role) == false) {
        redirect("../index.php");
    }
} else {
    redirect("../index.php");
}
?>

<div class="row">
    <!-- Blog Entries Column -->
    <div class="col-md-6 col-md-offset-3">
        <h3 class="text-center">Message</h3>
        <ul class="list-group">
            <?php 
            
            if(isset($_GET['id'])){
                $id = $_GET['id'];
                escape($id);

                $sql = "UPDATE subscriber_note SET status='Read' WHERE note_id='$id'";
                $query = query($sql);
                confirm($query);
                $sql = "SELECT * FROM subscriber_note WHERE note_id = '$id'";
                $query = query($sql);
                confirm($query);
                $result = mysqli_fetch_array($query);
                $time = $result['note_date'];
            }
            
            ?>
            <li class="list-group-item"> Date : <?php echo date("d-m-Y",$time); ?></li>
            <li class="list-group-item"> From : codermijan.com</li>
            <li class="list-group-item"> Subject : <?php echo $result['note_subject'] ?></li>
            <li class="list-group-item"><?php echo $result['note_message']; ?></li>
        </ul>
    </div>
    <!-- Blog Sidebar Widgets Column -->
    <!-- /.row -->

    <?php include("includes/footer.php"); ?>