<?php include("../../admin/includes/functions.php"); ?>
<?php 
if(isset($_SESSION['username'])){
    $username = $_SESSION['username'];
}else{
    redirect("../../index.php");
}

if(isset($_POST['basic'])){
    $sql = "UPDATE subscriber SET remaining_day = remaining_day+2629746, status = 'Running' , cv_sent_count = cv_sent_count +3 , package = 'Basic' WHERE username = '$username'";
    $query = query($sql);
    confirm($query);
    notify_reg("Renew Basic Package",$username);
    redirect("../index.php");
}elseif(isset($_POST['pro'])){
    $sql = "UPDATE subscriber SET remaining_day = remaining_day+15778476 , status = 'Running' , cv_sent_count = cv_sent_count +7 , package = 'Pro' WHERE username = '$username'";
    $query = query($sql);
    confirm($query);
    notify_reg("Renew Pro Package",$username);
    redirect("../index.php");
}elseif(isset($_POST['premium'])){
    $sql = "UPDATE subscriber SET remaining_day = remaining_day+31556952, status = 'Running' , cv_sent_count = cv_sent_count +10 , package = 'Premium' WHERE username = '$username'";
    $query = query($sql);
    confirm($query);
    notify_reg("Renew Premium Package",$username);
    redirect("../index.php");
}else{
    redirect("../renew.php");
}


?>