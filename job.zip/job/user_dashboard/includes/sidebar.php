    <!-- Blog Categories Well -->
    <div class="well" style="margin-top:150px">
        <div class="row">
            <div class="col-lg-12">
                <ul class="list-group">
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Email
                        <span class="badge badge-primary badge-pill"><?php echo $email; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Job Interest
                        <span class="badge badge-primary badge-pill"><?php echo $job_field; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Username
                        <span class="badge badge-primary badge-pill"><?php echo $username; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Package
                        <span class="badge badge-primary badge-pill"><?php echo $package; ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Status
                        <span class="badge badge-primary badge-pill"> <?php echo $status; ?> </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Interview Remaining
                        <span class="badge badge-primary badge-pill"> <?php echo $cv_count; ?> </span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        Expire Date
                        <span class="badge badge-primary badge-pill"><?php echo date("d-m-Y",$expire_date); ?></span>
                    </li>
                    <li class="list-group-item d-flex justify-content-between align-items-center">
                        CV
                        <span class="badge badge-primary badge-pill">
                        
                        <a style="color:white;text-decoration:none;" href="../admin/upload/<?php echo $cv_file; ?>"><?php echo $cv_file; ?></a>
                        
                        </span>
                    </li>
                </ul>
                <div class="form-group">
                    <button class="btn btn-success" style="width:49%;" type="submit" name="update">Update</button>
                    <a href="renew.php" class="btn btn-info" style="width:49%;">Renew</a>
                </div>
            </div>
            <!-- /.col-lg-6 -->
        </div>
        <!-- /.row -->
    </div>