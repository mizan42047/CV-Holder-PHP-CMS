    <nav class="navbar navbar-inverse navbar-fixed-top" role="navigation">
        <div class="container">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <a class="navbar-brand" href="../index.php">Start Bootstrap</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li>
                        <a href="index.php">User Dashboard</a>
                    </li>
                    <?php

                    if (user_type("Admin") || user_type("Developer") || user_type("Subscriber")) {
                        echo "<li><a href='../admin/logout.php'>Logout</a></li>";
                    }

                    if (user_type("Admin") || user_type("Developer")) {
                        echo "<li><a href='../admin/index.php'>Admin Panel</a></li>";
                    }

                    ?>
                    <li>
                        <a href="#" class="dropdown-toggle" data-toggle="dropdown"> <i class="fa fa-envelope"></i> <b class="badge badge-danger">
                        <?php
                                if (isset($_SESSION['email'])) {
                                    $email = $_SESSION['email'];
                                }

                                $unread_select = "SELECT * FROM subscriber_note WHERE status = 'Unread' AND note_email = '$email'";
                                $unread_query = query($unread_select);
                                confirm($unread_query);
                                $counter = counter($unread_query);
                                echo $counter;
                                ?></b></a>
                        <ul class="dropdown-menu message-dropdown">
                            <?php
                            if (isset($_SESSION['email'])) {
                                $email = $_SESSION['email'];
                            }
                            $result = find_user_by_email($email);
                            $user_email = $result['email'];
                            $sql = "SELECT * FROM subscriber_note WHERE note_email = '$user_email'";
                            $query = query($sql);
                            confirm($query);
                            if (!empty($query)) {
                                while ($result = mysqli_fetch_array($query)) { ?>
                                    <li class="message-preview">
                                        <a href="note_read.php?id=<?php echo $result['note_id']; ?>">
                                            <div class="media">
                                                <div class="media-body">
                                                    <div class="col-sm-12"><?php echo $result['note_subject']; ?> <button class="btn btn-info btn-sm">Read</button>
                                                    </div>
                                                </div>
                                            </div>
                                        </a>
                                    </li>
                            <?php }} ?>

                            <!-- Message -->
                            <li class="message-footer">
                                <a href="#">Read All New Messages</a>
                            </li>
                        </ul>
                    </li>
                </ul>
            </div>
            <!-- /.navbar-collapse -->
        </div>
        <!-- /.container -->
    </nav>