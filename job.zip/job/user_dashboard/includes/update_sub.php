<?php include("../../admin/includes/functions.php"); ?>

<?php


if (isset($_POST['update'])) {

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $details = $_POST['details'];
    $skill = $_POST['skill'];
    $photo = $_FILES['photo'];
    $user_cv = $_FILES['user_cv'];

    if (isset($_SESSION['username'])) {
        $result = find_by_username($_SESSION['username']);
        $id = $result['id'];
        if(empty($_SESSION['ucreate_error'])){
            update_sub($id, $fname, $lname, $details, $skill, $photo, $user_cv);
            redirect("../index.php");
        }else{
            redirect("../index.php");
        }
    }else{
        redirect("../../index.php");
    }
}else{
    redirect("../../index.php");
}
?>