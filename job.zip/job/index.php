<?php include("admin/includes/functions.php"); ?>
<?php include("includes/header.php"); ?>


<div class="row">
    <!-- Blog Entries Column -->
    <div class="col-md-8">
        <h2 class="text-center">Our Partners</h2>
        <hr>
        <?php

        if (isset($_SESSION['ucreate_success'])) {
            if (empty($_SESSION['ucreate_success'])) {
                $message = $_SESSION['ucreate_success'];
                echo '<div class="alert alert-success">' . $message . '</div>';
                session_unset($_SESSION['ucreate_success']);
            }
        }

        ?>
        <?php
        $query = find_all_company();
        while ($result = mysqli_fetch_array($query)) { ?>
            <div class="col-md-2">
                <img class="img-responsive thumbnail" src="admin/images/<?php echo $result['company_logo']; ?>" alt="">
            </div>
        <?php } ?>

        <div style="overflow:hidden;clear:both;"></div>
        <hr>
        <div class="columns">
            <ul class="price">
                <li class="header">Basic</li>
                <li class="grey">$ 9.99 / 1 Month</li>
                <li>3 Interview Call</li>
                <li>1 Month Review Team Support</li>
                <li>1 CV Accept</li>
                <li>CV Improvement Suggetion</li>
                <li class="grey">
                    <?php
                    
                    if (isset($_SESSION['username'])) {
                        echo '<a type="button" href="user_dashboard/renew.php" name="basic_plan" class="button btn">Subscribe</a>';
                    } else {
                        echo '<a type="button" href="reg.php" name="basic_plan" class="button btn">Subscribe</a>';
                    }

                    ?>
                </li>
            </ul>
        </div>

        <div class="columns">
            <ul class="price">
                <li class="header" style="background:blue;">Pro</li>
                <li class="grey">$ 19.99 / 6 Month</li>
                <li>7 Interview Call</li>
                <li>4 Month Review Team Support</li>
                <li>3 CV Accept</li>
                <li>CV Improvement Suggetion</li>
                <li class="grey">
                    <?php

                    if (isset($_SESSION['username'])) {
                        echo '<a type="button" href="user_dashboard/renew.php" name="basic_plan" class="button btn">Subscribe</a>';
                    } else {
                        echo '<a type="button" href="reg.php" name="basic_plan" class="button btn">Subscribe</a>';
                    }

                    ?>
                </li>
            </ul>
        </div>

        <div class="columns">
            <ul class="price">
                <li class="header" style="background:red;">Premium</li>
                <li class="grey">$ 29.99 / Year</li>
                <li>10 Interview Call</li>
                <li>6 Month Review Team Support</li>
                <li>10 CV Accept</li>
                <li>CV Improvement Suggetion</li>
                <li class="grey">
                    <?php

                    if (isset($_SESSION['username'])) {
                        echo '<a type="button" href="user_dashboard/renew.php" name="basic_plan" class="button btn">Subscribe</a>';
                    } else {
                        echo '<a type="button" href="reg.php" name="basic_plan" class="button btn">Subscribe</a>';
                    }

                    ?>
                </li>
            </ul>
        </div>
    </div>
    <!-- Blog Sidebar Widgets Column -->
    <div class="col-md-4">
        <?php include("includes/sidebar.php"); ?>
    </div>
    <!-- /.row -->

    <?php include("includes/footer.php"); ?>

    <script>
        var alert = document.querySelector(".alert");
        setInterval(function() {
            alert.style.display = "none";
        }, 2000);
    </script>