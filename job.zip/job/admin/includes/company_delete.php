<?php 
include("functions.php");
if(is_developer() == false){
    redirect("../../index.php");
}

if(isset($_GET['id'])){
    $id =  $_GET['id'];
    $image = find_image($id);
    if(unlink_image("../images/",$image)){
        if(delete_company($id)){
            redirect("../company.php");
        }else{
            redirect("../company.php");
        }
    }
}
