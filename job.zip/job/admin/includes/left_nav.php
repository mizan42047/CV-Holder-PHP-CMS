<div class="collapse navbar-collapse navbar-ex1-collapse">
    <ul class="nav navbar-nav side-nav">
        <li>
            <a href="index.php"><i class="fa fa-fw fa-dashboard"></i> Dashboard</a>
        </li>
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#company"><i class="fa fa-fw fa-table"></i>
                Company <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="company" class="collapse">
                <li>
                    <a href="company.php?source=add_company">Add Company</a>
                </li>
                <li>
                    <a href="company.php">Manage Company</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#user"><i class="fa fa-fw fa-table"></i>
                Subscriber <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="user" class="collapse">
                <li>
                    <a href="subscriber.php">Manage Subscriber</a>
                </li>
            </ul>
        </li>
        <li>
            <a href="javascript:;" data-toggle="collapse" data-target="#admin"><i class="fa fa-fw fa-table"></i>
                Admin <i class="fa fa-fw fa-caret-down"></i></a>
            <ul id="admin" class="collapse">
                <li>
                    <a href="admin.php?source=add_admin">Add Admin</a>
                    <a href="admin.php">Manage Admin</a>
                </li>
            </ul>
        </li>
    </ul>
</div>