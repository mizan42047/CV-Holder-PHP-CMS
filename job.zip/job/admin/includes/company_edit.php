<h2 class="page-header">
    Edit Partner Company
</h2>
<?php
if (isset($_GET['id'])) {
    $result = find_company_by_id($_GET['id']);
    if (isset($_POST['update'])) {
        if (update_company($_GET['id'],$_POST['name'], $_POST['description'], $_POST['adress'], $_POST['requirement'], $_POST['facilities'], $_FILES['logo']) == true) {
            $_SESSION['create_success'] = "Update Partner successfully";
        }
    }
}

?>

<form method="POST" action="" enctype="multipart/form-data">
    <div class="form-group">
        <label for="name">Company Name</label>
        <input type="text" name="name" class="form-control" value="<?php echo $result['company_name']; ?>" id="name" placeholder="Company Name...">
    </div>
    <div class="form-group">
        <label for="name">Company Description</label>
        <textarea name="description" class="form-control" id="description" cols="20" rows="10"><?php echo $result['company_description']; ?></textarea>
    </div>
    <div class="form-group">
        <label for="adress">Company Adress</label>
        <textarea name="adress" class="form-control" id="adress" cols="20" rows="10"><?php echo $result['company_adress']; ?></textarea>
    </div>
    <div class="form-group">
        <label for="requirement">Company Requirements</label>
        <textarea name="requirement" class="form-control" id="requirement" cols="10" rows="6"><?php echo $result['company_requirement']; ?></textarea>
    </div>
    <div class="form-group">
        <label for="facilities">Company Facilities</label>
        <textarea name="facilities" class="form-control" id="facilities" cols="10" rows="6"><?php echo $result['company_facilities']; ?></textarea>
    </div>
    <div class="form-group">
        <label><img style="width:50px;height:50px;" src="images/<?php echo $result['company_logo']; ?>"></label>
        <label for="logo">Company Logo</label>
        <input type="file" name="logo">
    </div>
    <input type="submit" value="Update Company" name="update" class="btn btn-block btn-primary">
</form>