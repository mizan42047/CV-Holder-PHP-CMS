<?php

if (isset($_POST['create'])) {
    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $username = $_POST['username'];
    $email = $_POST['email'];
    $pwd = $_POST['pwd'];
    create_admin($fname,$lname,$username,$email,$pwd);
}



?>

<h2 class="page-header">
    Add Admin
</h2>

<form method="POST" action="#" enctype="multipart/form-data">
    <div class="form-group">
        <input class="form-control" type="text" placeholder="First Name" name="fname">
    </div>
    <div class="form-group">
        <input class="form-control" type="text" placeholder="Last Name" name="lname">
    </div>
    <div class="form-group">
        <input class="form-control" type="text" placeholder="Username" name="username">
    </div>
    <div class="form-group">
        <input class="form-control" type="email" placeholder="E-mail" name="email">
    </div>
    <div class="form-group">
        <input class="form-control" type="password" placeholder="Password" name="pwd">
    </div>

    <input type="submit" value="Add Admin" name="create" class="btn btn-block btn-primary">
</form>