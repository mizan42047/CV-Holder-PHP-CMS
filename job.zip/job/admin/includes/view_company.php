<h2 class="page-header">
    Partner Company List
</h1>
<table class="table">
    <thead>
        <tr>
            <th scope="col">ID</th>
            <th scope="col">Name</th>
            <th scope="col">Description</th>
            <th scope="col">Adress</th>
            <th scope="col">Requirements</th>
            <th scope="col">Facilities</th>
            <th scope="col">Logo</th>
        </tr>
    </thead>
    <tbody>

        <?php
        $sql = "SELECT * FROM company";
        $company_data = query($sql);
        while ($result = mysqli_fetch_array($company_data)) :
        $company_id = $result['company_id'];
        ?>
            <tr>
                <th scope="row"><?php echo "#" . $result['company_id']; ?></th>
                <td><?php echo $result['company_name']; ?></td>
                <td><?php echo $result['company_description']; ?></td>
                <td><?php echo $result['company_adress']; ?></td>
                <td><?php echo $result['company_requirement']; ?></td>
                <td><?php echo $result['company_facilities']; ?></td>
                <td><img style="width:50px;height:50px;" src="<?php echo IMGROOT . $result['company_logo']; ?>" alt=""><br>
                    <a class="btn btn-sm btn-danger btn-block" href="includes/company_delete.php?id=<?php echo $company_id; ?>">Delete</a>
                    <a class="btn btn-sm btn-info btn-block" href="company.php?source=edit_company&id=<?php echo $company_id;?>">Edit</a>
                </td>
            </tr>
        <?php endwhile; ?>
    </tbody>
</table>