<?php include("config.php"); ?>
<?php ob_start();
session_start();

defined("DS") ? null : define("DS", DIRECTORY_SEPARATOR);
defined("SITEROOT") ? null : define("SITEROOT", "C:" . DS . "xampp" . DS . "htdocs" . DS . "job");
defined("FILEROOT") ? null : define("FILEROOT", SITEROOT . DS . "admin" . DS . "images" . DS);
defined("IMGROOT") ? null : define("IMGROOT", "images/");

function redirect($location)
{
    header("Location:$location");
}

function query($sql)
{
    global $connection;
    $query = mysqli_query($connection, $sql);
    return $query;
}

function counter($query)
{
    return mysqli_num_rows($query);
}

function escape($string)
{
    global $connection;
    return mysqli_real_escape_string($connection, $string);
}

function confirm($query)
{
    global $connection;
    if (!$query) {
        die("Query Failed" . mysqli_error($connection));
    }
}


function find_image($id)
{
    $sql = "SELECT `company`.`company_logo` FROM `company` WHERE `company`.`company_id` = '$id'";
    $query = query($sql);
    if (!empty($query)) {
        $result = mysqli_fetch_array($query);
        $image = $result['company_logo'];
        return $image;
    } else {
        return false;
    }
}

function unlink_image($location, $image)
{

    if (!empty($image)) {
        unlink("$location" . '/' . "$image");
        return true;
    } else {
        return false;
    }
}

function find_company_by_id($id)
{
    $id = escape($id);
    if (!empty($id)) {
        $sql = "SELECT * FROM `company` WHERE `company`.`company_id` = '$id'";
        $query = query($sql);
        confirm($query);
        if (!empty($query)) {
            $result = mysqli_fetch_array($query);
            return $result;
        } else {
            return false;
        }
    }
}

function find_all_company()
{
    $sql = "SELECT * FROM company";
    $query = query($sql);
    confirm($query);
    return $query;
}

function find_job_field()
{
    $sql = "SELECT * FROM job_field";
    $query = query($sql);
    confirm($query);
    return $query;
}

function company_valid($name, $description, $adress, $requirement, $facilities, $logo)
{
    $name = escape($name);
    $description = escape($description);
    $adress = escape($adress);
    $requirement = escape($requirement);
    $facilities = escape($facilities);

    $file_name = $logo['name'];
    $file_size = $logo['size'];
    $file_tmp = $logo['tmp_name'];
    $ex_file = explode('.', $file_name);
    $file_ext = strtolower(end($ex_file));
    $extensions = array("jpeg", "jpg", "png");


    if (empty($name) || empty($description) || empty($adress) || empty($requirement) || empty($facilities)) {
        $_SESSION['create_error'] = "You can't empty your field";
        redirect("../company.php?source=add_company");
    }

    if (in_array($file_ext, $extensions) === false) {
        $errors[] = "extension not allowed, please choose a JPEG or PNG file.";
        redirect("../company.php?source=add_company");
    }

    if ($file_size > 2097152) {
        $_SESSION['create_error'] = 'File size must be excately 2 MB';
        redirect("../company.php?source=add_company");
    }
}

function create_company($name, $description, $adress, $requirement, $facilities, $logo)
{

    $file_name = $logo['name'];
    $file_tmp = $logo['tmp_name'];

    company_valid($name, $description, $adress, $requirement, $facilities, $logo);
    if (empty($_SESSION['create_error']) == true) {
        move_uploaded_file($file_tmp, "../" . IMGROOT . $file_name);
        $sql = "INSERT INTO `company` (`company_name`, `company_description`, `company_adress`, `company_requirement`, `company_facilities`, `company_logo`) VALUES ('$name', '$description', '$adress', '$requirement', '$facilities', '$file_name')";
        query($sql);
        redirect("../company.php?source=add_company");
    } else {
        $_SESSION['create_error'] = 'Something went wrong';
        redirect("../company.php?source=add_company");
    }
}

function delete_company($id)
{
    $id = escape($id);
    if (!empty($id)) {
        $sql = "DELETE FROM `company` WHERE `company`.`company_id` = '$id'";
        $query = query($sql);
        confirm($query);
        return true;
    } else {
        return false;
    }
}

function update_company($id, $name, $description, $adress, $requirement, $facilities, $logo)
{
    $file_name = $logo['name'];
    $file_tmp = $logo['tmp_name'];
    company_valid($name, $description, $adress, $requirement, $facilities, $logo);

    if (empty($_SESSION['create_error']) == true) {
        if (!empty($file_name)) {
            $image = find_image($id);
            if (unlink_image("../images", $image)) {
                move_uploaded_file($file_tmp, IMGROOT . $file_name);
                $sql = "UPDATE `company` SET `company_name` = '$name', `company_description` = '$description', `company_adress` = '$adress', `company_requirement` = '$requirement', `company_facilities` = '$facilities' , `company_logo` = '$file_name' WHERE `company`.`company_id` = '$id'";
                query($sql);
                redirect("company.php");
            }
        } else {
            $image = find_image($id);
            $sql = "UPDATE `company` SET `company_name` = '$name', `company_description` = '$description', `company_adress` = '$adress', `company_requirement` = '$requirement', `company_facilities` = '$facilities' , `company_logo` = '$image' WHERE `company`.`company_id` = '$id'";
            query($sql);
            redirect("company.php");
        }
    } else {
        $_SESSION['create_error'] = 'Something went wrong';
        redirect("company.php");
    }
}

function valid_user($fname, $lname, $username, $email, $pwd, $job_field, $package, $details, $skill)
{
    $fname = escape($fname);
    $lname = escape($lname);
    $username = escape($username);
    $email = escape($email);
    $pwd = escape($pwd);
    $job_field = escape($job_field);
    $package = escape($package);
    $details = escape($details);
    $skill = escape($skill);

    if (empty($username) || empty($email) || empty($pwd) || empty($job_field) || empty($package)) {
        $_SESSION['ucreate_error'] = 'You must fill empty field';
    }
}
function valid_user_photo($user_photo)
{
    $file_name = $user_photo['name'];
    $file_size = $user_photo['size'];
    $ex_file = explode('.', $file_name);
    $file_ext = strtolower(end($ex_file));
    $extensions = array("jpeg", "jpg", "png");

    if (in_array($file_ext, $extensions) === false) {
        $_SESSION['ucreate_error'] = "extension not allowed, please choose a JPEG or PNG file.";
    }

    if ($file_size > 2097152) {
        $_SESSION['ucreate_error'] = 'File size must be excately 2 MB';
    }
}
function valid_user_cv($user_cv)
{
    $file_name = $user_cv['name'];
    $file_size = $user_cv['size'];
    $file_tmp = $user_cv['tmp_name'];
    $ex_file = explode('.', $file_name);
    $file_ext = strtolower(end($ex_file));
    $extensions = array("pdf");

    if (in_array($file_ext, $extensions) === false) {
        $_SESSION['ucreate_error'] = "extension not allowed, please choose a PDF file.";
    }

    if ($file_size > 2097152) {
        $_SESSION['ucreate_error'] = 'File size must be excately 2 MB';
    }
}

function valid_username($username)
{
    if (!empty($username)) {
        $sql = "SELECT username FROM subscriber WHERE username = '$username'";
        $query = query($sql);
        if (!empty($query)) {
            $result = mysqli_fetch_array($query);
            if ($result['username'] === $username) {
                $_SESSION['ucreate_error'] = 'Username Aready Exist';
            }
        }
    }
}
function valid_user_email($email)
{
    if (!empty($email)) {
        $sql = "SELECT email FROM subscriber WHERE email = '$email'";
        $query = query($sql);
        if (!empty($query)) {
            $result = mysqli_fetch_array($query);
            if ($result['email'] === $email) {
                $_SESSION['ucreate_error'] = 'Email Aready Exist';
            }
        }
    }
}

function reg_user($fname, $lname, $username, $email, $pwd, $job_field, $package, $details, $skill, $photo, $cv)
{
    global $connection;
    valid_user($fname, $lname, $username, $email, $pwd, $job_field, $package, $details, $skill);
    valid_user_photo($photo);
    valid_user_cv($cv);
    valid_user_email($email);
    valid_username($username);

    $photo_name = $photo['name'];
    $photo_tmp_name = $photo['tmp_name'];

    $cv_name = $cv['name'];
    $cv_tmp_name = $cv['tmp_name'];

    switch ($package) {
        case "Basic";
            $cv_sent = 3;
            $remaining_day = 2628000;
            break;
        case "Pro";
            $cv_sent = 5;
            $remaining_day = 15768000;
            break;
        case "Premium";
            $cv_sent = 10;
            $remaining_day = 31556952;
            break;
    }
    $pwd = password_hash($pwd, PASSWORD_DEFAULT);
    $time = time();

    if (empty($_SESSION['ucreate_error']) == true) {
        if (move_uploaded_file($photo_tmp_name, "../admin/images/" . $photo_name) && move_uploaded_file($cv_tmp_name, "../admin/upload/" . $cv_name)) {
            $sql = "INSERT INTO `subscriber` (`first_name`, `last_name`, `username`, `email`, `password`, `package`, `job_field`, `datails`, `skill`, `role`, `status`, `date`,`remaining_day`, `cv_file`, `photo`, `cv_sent_count`) VALUES ('$fname', '$lname', '$username', '$email', '$pwd', '$package', '$job_field', '$details', '$skill', 'Subscriber', 'Running', '$time','$remaining_day', '$cv_name', '$photo_name', '$cv_sent')";
            $query = query($sql);
            confirm($query);
            $last_id = mysqli_insert_id($connection);
            $result = find_user_by_id($last_id);
            $username = $result['username'];
            notify_reg(" New User Created Successfully", "$username");
            redirect("../index.php");
            $_SESSION['ucreate_success'] = 'Registation Done! Login Now';
        }
    } else {
        $_SESSION['ucreate_error'] = 'Something Went Wrong';
        redirect("../reg.php");
    }
}

function valid_login($email, $password)
{
    $email = escape($email);
    $password = escape($password);
    if (empty($email) || empty($password)) {
        $_SESSION['log_error'] = "Empty Field";
    }
}

function login_user($email, $password)
{
    valid_login($email, $password);
    if (empty($_SESSION['log_error'])) {
        $sql = "SELECT * FROM subscriber WHERE email = '$email'";
        $query = query($sql);
        confirm($query);
        if (!empty($query)) {
            $row = mysqli_fetch_array($query);
            $db_email = $row['email'];
            $db_pwd = $row['password'];
            $db_user = $row['username'];
            $db_role = $row['role'];

            if ($db_email === $email && password_verify($password, $db_pwd)) {
                if ($db_role === "Subscriber") {
                    $_SESSION['email'] = $db_email;
                    $_SESSION['username'] = $db_user;
                    $_SESSION['role'] = $db_role;
                    $_SESSION['password'] = $password;
                    redirect("../user_dashboard");
                } elseif ($db_role === "Admin") {
                    $_SESSION['email'] = $db_email;
                    $_SESSION['username'] = $db_user;
                    $_SESSION['role'] = $db_role;
                    $_SESSION['password'] = $password;
                    redirect("../admin/index.php");
                } elseif ($db_role === "Developer") {
                    $_SESSION['email'] = $db_email;
                    $_SESSION['username'] = $db_user;
                    $_SESSION['role'] = $db_role;
                    $_SESSION['password'] = $password;
                    redirect("../admin/index.php");
                } else {
                    redirect("../index.php");
                }
            } else {
                redirect("../index.php");
            }
        }
    }
}


function find_by_username($username)
{
    escape($username);
    if (!empty($username)) {
        $sql = "SELECT * FROM subscriber WHERE username = '$username'";
        $query = query($sql);
        confirm($query);
        $count = counter($query);

        if ($count > 0) {
            $result = mysqli_fetch_array($query);
            return $result;
        } else {
            return false;
        }
    } else {
        return false;
    }
}
function find_user_by_id($id)
{
    escape($id);
    if (!empty($id)) {
        $sql = "SELECT * FROM subscriber WHERE id = '$id'";
        $query = query($sql);
        confirm($query);
        $count = counter($query);

        if ($count > 0) {
            $result = mysqli_fetch_array($query);
            return $result;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function find_user_by_email($email)
{
    escape($email);
    if (!empty($email)) {
        $sql = "SELECT * FROM subscriber WHERE email = '$email'";
        $query = query($sql);
        confirm($query);
        $count = counter($query);

        if ($count > 0) {
            $result = mysqli_fetch_array($query);
            return $result;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function is_user_logged_in($username)
{
    $data = find_by_username($username);
    $username = $data['username'];
    if (!empty($_SESSION['username'])) {
        if ($_SESSION['username'] === $username) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function user_type($type)
{
    if (isset($_SESSION['role'])) {
        $user_role = $_SESSION['role'];
        if ($user_role == $type) {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function is_developer()
{
    if (isset($_SESSION['role'])) {
        $srole = $_SESSION['role'];
        if ($srole == "Developer") {
            return true;
        } else {
            return false;
        }
    } else {
        return false;
    }
}

function notify_reg($message, $last_user)
{
    $message = escape($message);
    if (!empty($message)) {
        $sql = "INSERT INTO notification (date,last_user,message) VALUES(current_timestamp(),'$last_user','$message')";
        $query = query($sql);
        confirm($query);
    }
}

function valid_update($fname, $lname, $details, $skill)
{
    $fname = escape($fname);
    $lname = escape($lname);
    $details = escape($details);
    $skill = escape($skill);
}

function notify_sub($email,$subject,$message)
{
    $message = escape($message);
    $subject = escape($subject);
    $email = escape($email);
    $date = time();
    if (!empty($subject) || !empty($email)) {
        $sql = "INSERT INTO subscriber_note (note_email,note_subject,note_message,note_date,status) VALUES('$email','$subject','$message','$date','Unread')";
        $query = query($sql);
        confirm($query);
    }
}


function update_sub($id, $fname, $lname, $details, $skill, $photo, $cv)
{
    valid_user_cv($cv);
    valid_user_photo($photo);
    $photo_name = $photo['name'];
    $photo_tmp = $photo['tmp_name'];
    $cv_name = $cv['name'];
    $cv_tmp = $cv['tmp_name'];
    $result = find_by_username($_SESSION['username']);
    $old_photo = $result['photo'];
    $old_cv = $result['cv_file'];
    if(empty($photo_name)){
        $photo_name = $old_photo;
    }
    if(empty($cv_name)){
        $cv_name = $old_cv;
    }
    move_uploaded_file($photo_tmp,"../../admin/images/".$photo_name);
    move_uploaded_file($cv_tmp,"../../admin/upload/".$cv_name);
    $sql = "UPDATE `subscriber` SET `first_name` = '$fname',`last_name` = '$lname',`datails` = '$details', `skill` = '$skill',`cv_file` = '$cv_name' ,`photo` = '$photo_name' WHERE `subscriber`.`id` = '$id'";
    $query = query($sql);
    confirm($query);
    
}

function create_admin($fname,$lname,$username,$email,$pwd)
{
    $fname = escape($fname);
    $lname = escape($lname);
    $username = escape($username);
    $email = escape($email);
    $pwd = escape($pwd);
    $date = time();

    if(empty($fname) && empty($lname) && empty($username) && empty($email) && empty($pwd)){
        $_SESSION['ucreate_error'] = "Empty field";
    }

    if(empty($_SESSION['ucreate_error'])){
        $sql = "INSERT INTO subscriber(first_name,last_name,username,email,password,date,role) VALUES('$fname','$lname','$username','$email','$pwd','$date','Admin')";
        $query = query($sql); 
        confirm($query);
    }
}


?>