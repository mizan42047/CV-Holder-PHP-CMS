<?php 
include("functions.php");

if(isset($_POST['create'])){

    if(create_company($_POST['name'],$_POST['description'],$_POST['adress'],$_POST['requirement'],$_POST['facilities'],$_FILES['logo']) == true){
        $_SESSION['create_success'] = "New Partner Added successfully";
    }
}






?>