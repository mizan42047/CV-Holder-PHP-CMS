<h2 class="page-header">
    Admin List
    </h1>
    <table class="table">
        <thead>
            <tr>
                <th scope="col">First Name</th>
                <th scope="col">Last Name</th>
                <th scope="col">Email</th>
                <th scope="col">Username</th>
                <th scope="col">Role</th>
                <th scope="col">Photo</th>
                <th scope="col">Action</th>
            </tr>
        </thead>
        <tbody>

            <?php
            $sql = "SELECT * FROM subscriber WHERE role = 'Admin' OR role = 'Developer'";
            $query = query($sql);
            if (!empty($query)) :
                while ($result = mysqli_fetch_array($query)) :
                    $admin_id = $result['id'];
            ?>
                    <tr>
                        <td><?php echo $result['first_name']; ?></td>
                        <td><?php echo $result['last_name']; ?></td>
                        <td><?php echo $result['email']; ?></td>
                        <td><?php echo $result['username']; ?></td>
                        <td><?php echo $result['role']; ?></td>
                        <td>
                            <?php
                            if (empty($result['photo'])) {
                                echo  '<img style="width:50px;height:50px;" src="images/admin.jpg" alt="User">';
                            } else {
                                echo  '<img style="width:50px;height:50px;" src="images/' . $result["photo"] . '" alt="User">';
                            }
                            ?>
                        </td>
                        <td><a class="btn btn-block btn-danger" href="includes/delete_admin.php?id=<?php echo $admin_id; ?>">Delete</a>
                        </td>
                    </tr>
            <?php endwhile;
            endif; ?>
        </tbody>
    </table>