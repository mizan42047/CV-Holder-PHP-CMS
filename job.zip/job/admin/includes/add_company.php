<h2 class="page-header">
    Add Partner Company
    </h2>
    
    <form method="POST" action="includes/create_company.php" enctype="multipart/form-data">
        <div class="form-group">
            <label for="name">Company Name</label>
            <input type="text" name="name" class="form-control" id="name" placeholder="Company Name...">
        </div>
        <div class="form-group">
            <label for="name">Company Description</label>
            <textarea name="description" class="form-control" id="description" cols="20" rows="10">Write Your Description...</textarea>
        </div>
        <div class="form-group">
            <label for="adress">Company Adress</label>
            <textarea name="adress" class="form-control" id="adress" cols="20" rows="10">Write Your Adress...</textarea>
        </div>
        <div class="form-group">
            <label for="requirement">Company Requirements</label>
            <textarea name="requirement" class="form-control" id="requirement" cols="10" rows="6">Write Your Requirements...</textarea>
        </div>
        <div class="form-group">
            <label for="facilities">Company Facilities</label>
            <textarea name="facilities" class="form-control" id="facilities" cols="10" rows="6">Write Your Facilities...</textarea>
        </div>
        <div class="form-group">
            <label for="logo">Company Logo</label>
            <input type="file" name="logo">
        </div>
        <input type="submit" value="Add Company" name="create" class="btn btn-block btn-primary">
    </form>