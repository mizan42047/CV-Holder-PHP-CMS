<?php include("functions.php"); ?>
<?php
if (isset($_GET['id'])) {
    if (is_developer() || user_type("Admin")) {
        escape($_GET['id']);
        $id = $_GET['id'];
        $sql = "DELETE FROM `subscriber` WHERE `subscriber`.`id` = '$id'";
        $query = query($sql);
        confirm($query);
        redirect("../admin.php");
    } else {
        redirect("../admin.php");
    }
} else {
    redirect("../../admin.php");
}
