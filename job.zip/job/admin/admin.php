<?php include("includes/header.php"); ?>
<?php include("includes/functions.php"); ?>

<?php

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if (is_user_logged_in($username) == false) {
        redirect("../index.php");
    } elseif (user_type($role) == false) {
        redirect("../index.php");
    }
} else {
    redirect("../index.php");
}

?>

<!-- Navigation -->
<?php include("includes/nav.php"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <?php

                if (isset($_GET['source'])) {
                    $source = escape($_GET['source']);
                } else {
                    $source = "";
                }

                switch ($source) {
                    case 'add_admin';
                        include('includes/add_admin.php');
                        break;
                    default:
                        include('includes/view_admin.php');
                }

                ?>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php include("includes/footer.php"); ?>
<script>
    ClassicEditor
        .create(document.querySelector('#description'))
        .catch(error => {
            console.error(error);
        });
    ClassicEditor
        .create(document.querySelector('#adress'))
        .catch(error => {
            console.error(error);
        });
    ClassicEditor
        .create(document.querySelector('#requirement'))
        .catch(error => {
            console.error(error);
        });
    ClassicEditor
        .create(document.querySelector('#facilities'))
        .catch(error => {
            console.error(error);
        });
</script>