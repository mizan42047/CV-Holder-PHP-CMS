<?php include("includes/header.php"); ?>
<?php include("includes/functions.php"); ?>

<?php

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if (is_user_logged_in($username) == false) {
        redirect("../index.php");
    } elseif (user_type("Admin") == false && user_type("Developer") == false) {
        redirect("../index.php");
    }
} else {
    redirect("../index.php");
}

if (isset($_POST['send_note'])) {
    $email = $_POST['email'];
    $subject = $_POST['subject'];
    $body = $_POST['body'];
    notify_sub($email, $subject, $body);
}

// Import PHPMailer classes into the global namespace
// These must be at the top of your script, not inside a function
/* use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;

// Load Composer's autoloader
require '../vendor/autoload.php';

// Instantiation and passing `true` enables exceptions
$mail = new PHPMailer(true);

try {
    //Server settings
    $mail->SMTPDebug = SMTP::DEBUG_SERVER;                      // Enable verbose debug output
    $mail->isSMTP();                                            // Send using SMTP
    $mail->Host       = 'smtp.example.com';                    // Set the SMTP server to send through
    $mail->SMTPAuth   = true;                                   // Enable SMTP authentication
    $mail->Username   = 'user@example.com';                     // SMTP username
    $mail->Password   = 'secret';                               // SMTP password
    $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;         // Enable TLS encryption; `PHPMailer::ENCRYPTION_SMTPS` encouraged
    $mail->Port       = 587;                                    // TCP port to connect to, use 465 for `PHPMailer::ENCRYPTION_SMTPS` above

    //Recipients
    $mail->setFrom('from@example.com', 'Mailer');
    $mail->addAddress('joe@example.net', 'Joe User');     // Add a recipient
    $mail->addAddress('ellen@example.com');               // Name is optional
    $mail->addReplyTo('info@example.com', 'Information');
    $mail->addCC('cc@example.com');
    $mail->addBCC('bcc@example.com');

    // Attachments
    $mail->addAttachment('/var/tmp/file.tar.gz');         // Add attachments
    $mail->addAttachment('/tmp/image.jpg', 'new.jpg');    // Optional name

    // Content
    $mail->isHTML(true);                                  // Set email format to HTML
    $mail->Subject = 'Here is the subject';
    $mail->Body    = 'This is the HTML message body <b>in bold!</b>';
    $mail->AltBody = 'This is the body in plain text for non-HTML mail clients';

    $mail->send();
    echo 'Message has been sent';
} catch (Exception $e) {
    echo "Message could not be sent. Mailer Error: {$mail->ErrorInfo}";
} */

if (isset($_POST['sent_cv'])) {
    $id = $_POST['id'];
    if (!empty($id)) {
        $sql = "UPDATE subscriber SET cv_sent_count = cv_sent_count -1 WHERE id = '$id'";
        $query = query($sql);
        confirm($query);
        echo "<script>alert('We are not agrementaly prepared');</script>";
    }
}

?>

<!-- Navigation -->
<?php include("includes/nav.php"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <h2 class="page-header">
                    Subscriber List
                    </h1>
                    <table class="table">
                        <thead>
                            <tr>
                                <th scope="col">Email</th>
                                <th scope="col">Remaining CV</th>
                                <th scope="col">Status</th>
                                <th scope="col">Package</th>
                                <th scope="col">Job Interest</th>
                                <th scope="col">CV</th>
                                <th scope="col">Photo</th>
                                <th scope="col">Send CV</th>
                                <th scope="col">Send Note</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php
                            $sql = "SELECT * FROM subscriber WHERE role = 'Subscriber' AND status ='Running' AND cv_sent_count != 0";
                            $query = query($sql);
                            confirm($query);
                            if (!empty($query)){
                                while ($result = mysqli_fetch_array($query)){?>
                                    <tr>
                                        <td><?php echo $result['email']; ?></td>
                                        <td><?php echo $result['cv_sent_count']; ?></td>
                                        <td><?php echo $result['status']; ?></td>
                                        <td><?php echo $result['package']; ?></td>
                                        <td><?php echo $result['job_field']; ?></td>
                                        <td><?php
                                            if (empty($result['cv_file'])) {
                                                echo "No CV";
                                            } else {
                                                echo "<a href='upload/" . $result['cv_file'] . "'>CV</a>";
                                            }
                                            ?></td>
                                        <td>
                                            <?php
                                            if (empty($result['photo'])) {
                                                echo  '<img style="width:50px;height:50px;" src="images/pngtree-user-vector-avatar-png-image_1541962.jpg" alt="User">';
                                            } else {
                                                echo  '<img style="width:50px;height:50px;" src="images/' . $result["photo"] . '" alt="User">';
                                            }
                                            ?>
                                        </td>
                                        <td>
                                            <form action="#" method="POST">
                                                <input type="hidden" name="cv_file" value="<?php echo $result['cv_file']; ?>">
                                                <input type="hidden" name="id" value="<?php echo $result['id']; ?>">
                                                <select class="form-control" name="cv_name" id="">
                                                    <?php

                                                    $select_company = find_all_company();
                                                    while ($row = mysqli_fetch_array($select_company)) {
                                                        echo '<option value="' . $row['company_name'] . '">' . $row['company_name'] . '</option>';
                                                    }
                                                    ?>
                                                </select>
                                                <button class="btn btn-sm btn-block btn-primary" onclick="javascript: return confirm('Are you sure?')" type="submit" name="sent_cv">Send CV</button>
                                            </form>
                                        </td>
                                        <td>
                                            <button type="button" class="btn btn-success btn-block" data-toggle="modal" data-target=".bd-example-modal-lg">Send Note</button>

                                            <div class="modal fade bd-example-modal-lg" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
                                                <div class="modal-dialog modal-lg">
                                                    <div class="modal-content">
                                                        <div class="container-fluid">
                                                            <div style="margin-top: 40px;">
                                                                <h1 style="text-align: center; color: #6A33D3; margin: 0; padding: 0;">
                                                                    Send Notification</h1>
                                                                <div style="background: #fff; padding: 30px; border-radius: 10px; max-width: 500px ; margin: auto;">
                                                                    <form action="#" method="POST">
                                                                        <div class="form-group">
                                                                            <li class="list-group-item d-flex justify-content-between align-items-center">
                                                                                Email
                                                                                <span class="badge badge-primary badge-pill"><?php echo $result['email']; ?></span>
                                                                            </li>
                                                                        </div>
                                                                        <input type="hidden" value="<?php echo $result['email']; ?>" name="email">
                                                                        <div class="form-group">
                                                                            <input class="form-control" type="text" placeholder="Subject" name="subject">
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <textarea name="body" class="form-control" id="" cols="30" rows="7">Write Your Body...</textarea>
                                                                        </div>
                                                                        <div class="form-group">
                                                                            <button class="btn btn-success btn-block" type="submit" name="send_note">Send</button>
                                                                        </div>
                                                                    </form>
                                                                </div>
                                                            </div>
                                                        </div>
                                                    </div>
                                                </div>
                                            </div>
                                        </td>
                                    </tr>
                            <?php }} ?>
                        </tbody>
                    </table>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php include("includes/footer.php"); ?>