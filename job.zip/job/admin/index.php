<?php include("includes/header.php"); ?>
<?php include("includes/functions.php"); ?>

<?php

if (isset($_SESSION['username']) && isset($_SESSION['role'])) {
    $username = $_SESSION['username'];
    $role = $_SESSION['role'];
    if (is_user_logged_in($username) == false) {
        redirect("../index.php");
    } elseif (user_type("Admin") == false && user_type("Developer") == false) {
        redirect("../index.php");
    }
} else {
    redirect("../index.php");
}

?>

<!-- Navigation -->
<?php include("includes/nav.php"); ?>

<div id="page-wrapper">

    <div class="container-fluid">

        <!-- Page Heading -->
        <div class="row">
            <div class="col-lg-12">
                <div class="row">
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-primary">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-building fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <?php
                                        $query = find_all_company();
                                        $counter = counter($query);

                                        ?>
                                        <div class='huge'><?php echo $counter; ?></div>
                                        <div>Company</div>
                                    </div>
                                </div>
                            </div>
                            <a href="company.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-green">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-step-forward fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <?php
                                        $sql = "SELECT * FROM subscriber WHERE role = 'Subscriber'";
                                        $query = query($sql);
                                        $counter = counter($query);
                                        ?>
                                        <div class='huge'><?php echo $counter; ?></div>
                                        <div>Subscriber</div>
                                    </div>
                                </div>
                            </div>
                            <a href="subscriber.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-yellow">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-user fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">
                                        <?php
                                        $sql = "SELECT * FROM subscriber WHERE role = 'Admin' OR role = 'Developer'";
                                        $query = query($sql);
                                        $counter = counter($query);

                                        ?>
                                        <div class='huge'><?php echo $counter; ?></div>
                                        <div> Admin </div>
                                    </div>
                                </div>
                            </div>
                            <a href="admin.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-md-6">
                        <div class="panel panel-red">
                            <div class="panel-heading">
                                <div class="row">
                                    <div class="col-xs-3">
                                        <i class="fa fa-check-square fa-5x"></i>
                                    </div>
                                    <div class="col-xs-9 text-right">

                                        <?php
                                        $sql = "SELECT * FROM subscriber WHERE role = 'Subscriber' AND status ='Running'";
                                        $query = query($sql);
                                        $counter = counter($query);
                                        ?>

                                        <div class='huge'><?php echo $counter; ?></div>
                                        <div>Active Subscriber</div>
                                    </div>
                                </div>
                            </div>
                            <a href="subscriber.php">
                                <div class="panel-footer">
                                    <span class="pull-left">View Details</span>
                                    <span class="pull-right"><i class="fa fa-arrow-circle-right"></i></span>
                                    <div class="clearfix"></div>
                                </div>
                            </a>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- /.row -->

    </div>
    <!-- /.container-fluid -->

</div>
<!-- /#page-wrapper -->

<?php include("includes/footer.php"); ?>