<?php include("includes/functions.php"); ?>
<?php 

if(isset($_SESSION)){
    session_destroy();
    redirect("../index.php");
}else{
    redirect("../index.php");
}

?>